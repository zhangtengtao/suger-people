﻿The mod CustomBuki is Copyright (c) 2016 by ici2cc and the intellectual property of the author.
 It may be not be reproduced under any circumstances except for personal,
 private use as long as it remains in its unaltered, unedited form.
 It may not be placed on any web site or otherwise distributed publicly without advance written permission.
 Use of this mod on any other website or as a part of any public display is strictly prohibited and a violation of copyright.

CustomBuki版权归ici2cc所有.除非是个人使用,否则任何人不得在任何情况下复制本作品,同时也要保证作品本身不被修改.
任何人在未经授权的情况下不得在任何网站或以其他方式公开二次发布本作品.
使用本作品的一部分在其他任何网站或公开展示都是被严格禁止的侵犯著作权行为.
对于任何侵犯著作权的行为，本人保留诉诸法律途径的权利.

CustomBukiの著作権はすべてici2ccに所有します。
個人のみの使用が可能、その以外の情況では本作品に対するコピーが禁じる、
その同時本作品に対する編集も遠慮します。どのサイトやその他の方法で本作を公開二次配布する時、
転載を認可されない場合は禁じます。本作品の一部を使用し、他のサイトでの発表や公開展示は禁じられた著作権侵害行為。

Email:ici2cc@hotmail.com
      fengxingssdua@hotmail.com
	  fengxingssdua@yeah.net
web:csmod.net custombuki.com ici2cc.com

password:CustomBuki1710090*
解压密码:CustomBuki1710090*
パスワード:CustomBuki1710090*